import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import MagicMock, patch

import worker as w


def article(url):
    return {'url': url, 'text': 'Readable evidence. ' * 100, 'sha256': 'example'}


class SourceTests(unittest.TestCase):
    def test_google_wrapper_resolves_before_article_fetch_and_caches(self):
        wrapper = 'https://news.google.com/rss/articles/example'
        target = 'https://publisher.example/article'
        decoder = MagicMock()
        decoder.__enter__.return_value.decode_google_news_url.return_value = {
            'success': True, 'decoded_url': target}
        html = ('<html><p>' + 'Documented article text. ' * 60 + '</p></html>').encode()
        with tempfile.TemporaryDirectory() as tmp, patch.object(w, 'WORK', Path(tmp)), \
                patch.object(w, 'public_url', side_effect=lambda u: u), \
                patch('googlenewsdecoder.GoogleDecoder', return_value=decoder) as make, \
                patch.object(w, 'http', return_value=(html, target, 'text/html')) as http:
            self.assertEqual(w.source_text(wrapper)['url'], target)
            self.assertEqual(w.publisher_url(wrapper), target)
            self.assertEqual(make.call_count, 1)
            self.assertEqual(http.call_args.args[0], target)

    def test_decoded_private_url_is_rejected(self):
        decoder = MagicMock()
        decoder.__enter__.return_value.decode_google_news_url.return_value = {
            'success': True, 'decoded_url': 'https://127.0.0.1/private'}
        with tempfile.TemporaryDirectory() as tmp, patch.object(w, 'WORK', Path(tmp)), \
                patch('googlenewsdecoder.GoogleDecoder', return_value=decoder):
            with self.assertRaises(w.Hold):
                w.publisher_url('https://news.google.com/rss/articles/example')

    def test_decode_error_does_not_leak_remote_message(self):
        decoder = MagicMock()
        decoder.__enter__.return_value.decode_google_news_url.return_value = {
            'success': False, 'message': 'https://remote.example/?key=secret'}
        with tempfile.TemporaryDirectory() as tmp, patch.object(w, 'WORK', Path(tmp)), \
                patch('googlenewsdecoder.GoogleDecoder', return_value=decoder):
            with self.assertRaises(w.Wait) as caught:
                w.publisher_url('https://news.google.com/rss/articles/example')
            self.assertNotIn('secret', str(caught.exception))

    def test_fallback_search_when_gdelt_is_down(self):
        rss = b'''<rss><channel><item><title>Hair follicle growth mechanism discovered</title>
          <link>https://news.google.com/rss/articles/one</link></item>
          <item><title>Hair follicle growth research explained</title>
          <link>https://news.google.com/rss/articles/two</link></item>
          <item><title>Unrelated game released</title><link>https://bad.example/</link></item>
          </channel></rss>'''
        with patch.object(w, 'json_http', side_effect=w.Wait('Service HTTP 503')), \
                patch.object(w, 'http', return_value=(rss, '', 'text/xml')), \
                patch.object(w, 'publisher_url', side_effect=[
                    'https://alpha.example/article', 'https://beta.example/article']):
            self.assertEqual(w.corroborating_urls('Hair follicle growth mechanism explained - Publisher'),
                             ['https://alpha.example/article', 'https://beta.example/article'])

    def test_original_article_is_used_before_search(self):
        with tempfile.TemporaryDirectory() as tmp, \
                patch.object(w, 'source_text', side_effect=lambda u: article(u)) as fetch, \
                patch.object(w, 'corroborating_urls', return_value=['https://beta.example/article']):
            sources = w.collect_sources({'title': 'A topic', 'source_urls': ['https://alpha.example/article']}, Path(tmp))
            self.assertEqual(fetch.call_args_list[0].args[0], 'https://alpha.example/article')
            self.assertEqual([s['id'] for s in sources], ['s1', 's2'])

    def test_same_domain_and_www_alias_do_not_meet_two_source_rule(self):
        with tempfile.TemporaryDirectory() as tmp, \
                patch.object(w, 'source_text', side_effect=lambda u: article(u)), \
                patch.object(w, 'corroborating_urls', return_value=[]):
            with self.assertRaisesRegex(w.Hold, 'retrieved 1'):
                w.collect_sources({'title': 'A topic', 'source_urls': [
                    'https://alpha.example/one', 'https://www.alpha.example/two']}, Path(tmp))

    def test_partial_evidence_survives_temporary_second_source_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            entry = {'title': 'A topic', 'source_urls': ['https://alpha.example/article']}
            with patch.object(w, 'source_text', side_effect=[article('https://alpha.example/article'), w.Wait('Service HTTP 503')]), \
                    patch.object(w, 'corroborating_urls', return_value=['https://beta.example/article']):
                with self.assertRaises(w.Wait):
                    w.collect_sources(entry, folder)
            self.assertEqual(len(json.loads((folder / 'sources.json').read_text())), 1)
            entry['source_urls'] = []
            with patch.object(w, 'source_text', return_value=article('https://beta.example/article')) as fetch, \
                    patch.object(w, 'corroborating_urls', return_value=['https://beta.example/article']):
                self.assertEqual(len(w.collect_sources(entry, folder)), 2)
                self.assertEqual(fetch.call_count, 1)

    def test_migration_only_retries_old_source_holds_once(self):
        state = {'jobs': {
            'source': {'status': 'HOLD', 'blocker': 'Need two readable source URLs; old failure'},
            'editor': {'status': 'HOLD', 'blocker': 'Editor rejected candidate'},
            'ready': {'status': 'REVIEW_REQUIRED'},
        }}
        w.reopen_source_holds(state)
        self.assertEqual(state['jobs']['source']['status'], 'QUEUED')
        self.assertEqual(state['jobs']['editor']['status'], 'HOLD')
        self.assertEqual(state['jobs']['ready']['status'], 'REVIEW_REQUIRED')
        state['jobs']['source'].update(status='HOLD', blocker='Need two readable source URLs; still blocked')
        w.reopen_source_holds(state)
        self.assertEqual(state['jobs']['source']['status'], 'HOLD')

    def test_report_shows_zero_videos_and_blocker_in_mobile_log(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(w, 'OUTPUT', Path(tmp)), \
                contextlib.redirect_stdout(io.StringIO()) as stdout:
            w.report({'jobs': {'one': {'id': 'one', 'title': 'A topic', 'status': 'HOLD',
                                      'blocker': 'Source unavailable'}}}, [])
            self.assertIn('Video files in this run: **0**', stdout.getvalue())
            self.assertIn('Source unavailable', stdout.getvalue())

    def test_source_hold_never_reaches_model_or_renderer(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(w, 'WORK', Path(tmp)), \
                patch.object(w, 'collect_sources', side_effect=w.Hold('Need two readable source URLs')), \
                patch.object(w, 'ai') as ai, patch.object(w, 'render') as render:
            with self.assertRaises(w.Hold):
                w.process({'id': 'example'}, None, 30)
            ai.assert_not_called()
            render.assert_not_called()

    def test_same_story_sources_cannot_supply_another_video_in_batch(self):
        sources = [dict(article('https://alpha.example/event'), id='s1'),
                   dict(article('https://beta.example/event'), id='s2')]
        with tempfile.TemporaryDirectory() as tmp, patch.object(w, 'WORK', Path(tmp)), \
                patch.object(w, 'collect_sources', return_value=sources), patch.object(w, 'ai') as ai:
            with self.assertRaisesRegex(w.Hold, 'already used'):
                w.process({'id': 'same-event', '_excluded_story_sources': ['https://alpha.example/event']}, None, 30)
            ai.assert_not_called()

    def test_waiting_job_does_not_starve_next_queued_job(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            state_dir, output_dir = root / 'state', root / 'output'
            state_dir.mkdir()
            state = {'schema_version': 3, 'jobs': {
                'waiting': {'id': 'waiting', 'title': 'First', 'status': 'WAITING',
                            'created_at': '2026-11-01', 'last_attempt_at': '2026-11-15',
                            'youtube_signal': {'status': 'not_checked'}},
                'queued': {'id': 'queued', 'title': 'Second', 'status': 'QUEUED',
                           'created_at': '2026-11-02', 'youtube_signal': {'status': 'not_checked'}},
            }}
            w.atomic_json(state_dir / 'queue.json', state)
            with patch.object(w, 'ROOT', root), patch.object(w, 'STATE', state_dir), \
                    patch.object(w, 'OUTPUT', output_dir), patch('sys.argv', ['worker.py']), \
                    patch.dict('os.environ', {'MAX_JOBS_PER_RUN': '1', 'TARGET_SECONDS': '30'}), \
                    patch.object(w, 'process', side_effect=w.Wait('Temporarily unavailable')) as process, \
                    contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(w.main(), 0)
                self.assertEqual(process.call_args.args[0]['id'], 'queued')


if __name__ == '__main__':
    unittest.main()
