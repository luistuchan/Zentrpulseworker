import contextlib
from datetime import datetime, timedelta, timezone
from email.utils import format_datetime
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from xml.sax.saxutils import escape

import worker as w


def rss(items):
    return ('<rss><channel>' + ''.join(
        '<item><title>' + escape(title) + '</title><link>https://news.google.com/rss/articles/test</link>'
        '<pubDate>' + date + '</pubDate></item>' for title, date in items) + '</channel></rss>').encode()


class NewsTests(unittest.TestCase):
    def test_freshness_rejects_stale_missing_and_future_dates(self):
        now = datetime.now(timezone.utc)
        self.assertTrue(w.news_is_fresh((now - timedelta(hours=4)).isoformat()))
        for date in (None, 'bad', now.replace(tzinfo=None).isoformat(),
                     (now - timedelta(hours=49)).isoformat(), (now + timedelta(hours=1)).isoformat()):
            self.assertFalse(w.news_is_fresh(date))

    def test_discovery_reserves_news_slots_and_filters_old_and_partisan_items(self):
        now = datetime.now(timezone.utc)
        recent, old = format_datetime(now - timedelta(hours=2)), format_datetime(now - timedelta(days=3))
        def response(url, **kwargs):
            if 'world-query' in url:
                data = rss([('Major earthquake prompts international rescue effort', recent),
                            ('Old international development from three days ago', old),
                            ('Opinion: A lengthy argument about world affairs', recent)])
            elif 'president-query' in url:
                data = rss([('US president announces major disaster assistance', recent),
                            ('President campaign fundraising and polls update', recent)])
            else:
                data = rss([('Why a hidden ocean mechanism changes the tide', recent)])
            return data, url, 'text/xml'
        with patch.object(w, 'CATEGORIES', {'science': 'science-query', 'world_news': 'world-query',
                                           'president': 'president-query'}), patch.object(w, 'http', side_effect=response):
            leads, errors = w.discover(3)
        self.assertEqual(errors, [])
        self.assertEqual([x['category'] for x in leads], ['world_news', 'president', 'science'])
        self.assertEqual(leads[0]['content_type'], 'news_update')
        self.assertIsNotNone(leads[0]['source_published_at'])
        self.assertEqual(leads[2]['content_type'], 'explainer')

    def test_stale_news_cannot_reach_sources_or_ai(self):
        with patch.object(w, 'collect_sources') as fetch, patch.object(w, 'ai') as ai:
            with self.assertRaisesRegex(w.Hold, 'expired'):
                w.process({'id': 'stale', 'content_type': 'news_update',
                           'source_published_at': (datetime.now(timezone.utc) - timedelta(days=3)).isoformat()}, None, 30)
            fetch.assert_not_called()
            ai.assert_not_called()

    def test_scheduler_keeps_unfinished_news_batch_and_expires_old_news(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            state_dir = root / 'state'
            state_dir.mkdir()
            state = {'schema_version': 3, 'jobs': {
                'explain': {'id': 'explain', 'title': 'An older explanation', 'status': 'QUEUED',
                            'category': 'science',
                            'created_at': '2026-01-01', 'youtube_signal': {'status': 'not_checked'}},
                'news': {'id': 'news', 'title': 'A current world development', 'status': 'QUEUED',
                         'category': 'world_news',
                         'content_type': 'news_update', 'created_at': w.now(), 'source_published_at': w.now(),
                         'youtube_signal': {'status': 'not_checked'}},
                'expired': {'id': 'expired', 'title': 'Old news', 'status': 'QUEUED',
                            'content_type': 'news_update', 'source_published_at': '2020-01-01T00:00:00+00:00'},
            }}
            w.atomic_json(state_dir / 'queue.json', state)
            with patch.object(w, 'ROOT', root), patch.object(w, 'STATE', state_dir), \
                    patch.object(w, 'OUTPUT', root / 'output'), patch('sys.argv', ['worker.py']), \
                    patch.dict('os.environ', {'MAX_JOBS_PER_RUN': '1', 'TARGET_SECONDS': '30'}), \
                    patch.object(w, 'process', side_effect=w.Wait('Temporary source failure')) as process, \
                    contextlib.redirect_stdout(io.StringIO()):
                w.main()
                self.assertEqual(process.call_args.args[0]['id'], 'news')
                w.main()
                self.assertEqual(process.call_args.args[0]['id'], 'news')
            updated = w.load(state_dir / 'queue.json', {})
            self.assertEqual(updated['jobs']['expired']['status'], 'HOLD')


if __name__ == '__main__':
    unittest.main()
