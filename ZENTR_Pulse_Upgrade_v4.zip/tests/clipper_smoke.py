"""Synthetic end-to-end clipper render; no API, download, or model needed."""
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import worker as w
import clipper
from test_clipper import words


def main():
    with tempfile.TemporaryDirectory(prefix='pulse-clipper-') as tmp:
        root = Path(tmp)
        source = root/'source.mp4'
        w.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=size=320x180:rate=30:duration=42',
               '-f','lavfi','-i','sine=frequency=1000:sample_rate=48000:duration=42',
               '-c:v','libx264','-preset','ultrafast','-pix_fmt','yuv420p','-c:a','aac','-shortest',str(source)])
        entry = {'id': 'synthetic-clipper', 'title': 'Synthetic clipper integration fixture',
                 'content_type': 'clipper', 'category': 'clipper', 'transcript_words': words(),
                 'media': {'path': source.name, 'sha256': w.digest(source), 'rights_confirmed': True,
                           'rights_note': 'Synthetic test pattern and tone; not a publishable clip'}}
        with patch.object(w,'ROOT',root), patch.object(w,'WORK',root/'work'), patch.object(w,'OUTPUT',root/'output'):
            w.process(entry, None, 20)
            output = root/'output'/'synthetic-clipper'/'video.mp4'
            assert entry['status'] == 'REVIEW_REQUIRED'
            review = json.loads((output.parent/'review.json').read_text())
            assert review['quality']['dimensions'] == [1080,1920]
            assert review['quality']['audio'] and review['quality']['decode'] == 'passed'
            assert review['source_media_sha256'] == w.digest(source)
            assert all(s['mode'] == 'full_scene_blur' for s in review['shots'])
            assert (output.parent/'preview.jpg').exists()
            if os.getenv('CLIPPER_QA_DIR'):
                qa=Path(os.environ['CLIPPER_QA_DIR']); qa.mkdir(parents=True,exist_ok=True)
                shutil.copy2(output.parent/'preview.jpg',qa/'clipper-preview.jpg')
            # Also exercise the actual interpolated crop filter used for faces.
            folder=root/'crop'; folder.mkdir()
            selected=words()[:6]
            crop_output=root/'crop-output'/'video.mp4'
            points=[[0,100,70,30],[1,125,72,30],[2,145,75,30]]
            quality=clipper.render(source,selected,0,2.65,[{'start':0,'end':2.65,
                'centers':points,'speaker_track':1,'mode':'face_follow'}],folder,crop_output,w)
            assert quality['decode']=='passed'
            print('CLIPPER INTEGRATION PASSED: excerpt, original audio, timed captions, 1080x1920,')
            print('full-scene fallback, interpolated crop filter, preview, review metadata and full decode.')


if __name__=='__main__': main()
