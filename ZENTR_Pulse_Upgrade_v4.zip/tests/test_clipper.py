import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import MagicMock, patch

import worker as w
import clipper as c


def words():
    result = []
    for sentence in range(14):
        for i, text in enumerate(('This', 'actually', 'explains', 'why', 'it', 'happened.')):
            t = sentence * 3 + i * .45
            result.append({'start': t, 'end': t + .4, 'word': text})
    return result


class ClipperTests(unittest.TestCase):
    def test_highlight_is_contiguous_original_words_at_sentence_boundaries(self):
        original = words()
        start, end, chosen = c.choose_highlight(original, 20, w)
        self.assertGreaterEqual(end-start, 15)
        self.assertLessEqual(end-start, 25)
        self.assertTrue(chosen[-1]['word'].endswith('.'))
        i = original.index(chosen[0])
        self.assertEqual(chosen, original[i:i+len(chosen)])

    def test_bad_word_times_are_rejected(self):
        for changed in ({'start': float('nan')}, {'end': -1}, {'word': ''}, {'start': 100}):
            sample = words()
            sample[1].update(changed)
            with self.assertRaises(w.Hold):
                c.validate_words(sample, 42, w)

    def test_shot_changes_follow_sentence_boundaries_and_ambiguous_shot_stays_wide(self):
        sample = words()[:12]
        points = [{'time': t, 'faces': [
            {'id': 1, 'box': [10,10,20,20], 'score': 1},
            {'id': 2, 'box': [100,10,20,20], 'score': 12}]} for t in (.1,.5,1.,1.5,2.,2.5)]
        points += [{'time': t, 'faces': [
            {'id': 1, 'box': [10,10,20,20], 'score': 1},
            {'id': 2, 'box': [100,10,20,20], 'score': 1}]} for t in (3.,3.5,4.,4.5,5.)]
        shots = c.shot_plan(sample, 0, 5.65, points)
        self.assertEqual(shots[0]['speaker_track'], 2)
        self.assertEqual(shots[1]['mode'], 'full_scene_blur')
        self.assertEqual(shots[1]['start'], sample[5]['end'])

    def test_captions_keep_original_words_and_word_timing(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'captions.ass'
            c.caption_file(words()[:6], 0, 3, path, w)
            content = path.read_text()
            self.assertIn('This actually explains why', content)
            self.assertIn('0:00:02.65', content)
            self.assertIn('it happened.', content)

    def test_local_source_requires_matching_manifest_hash(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(w, 'ROOT', Path(tmp)):
            p = Path(tmp)/'source.mp4'; p.write_bytes(b'fixture')
            entry = {'media': {'path': p.name, 'rights_confirmed': True, 'rights_note': 'Owned', 'sha256': 'wrong'}}
            with self.assertRaises(w.Hold):
                c.source_media(entry, Path(tmp), w)
            entry['media']['sha256'] = w.digest(p)
            self.assertEqual(c.source_media(entry, Path(tmp), w)[0], p)

    def test_same_original_video_cannot_be_reused(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(w, 'WORK', Path(tmp)):
            p = Path(tmp)/'renamed.mp4'; p.write_bytes(b'same source bytes')
            entry = {'id': 'repeat', '_excluded_media_hashes': [w.digest(p)]}
            with patch.object(c, 'source_media', return_value=(p, {})), patch.object(c, 'transcript') as transcribe:
                with self.assertRaisesRegex(w.Hold, 'already clipped'):
                    c.process(entry, 20, api=w)
                transcribe.assert_not_called()

    def test_cc_discovery_excludes_standard_license_and_uses_original_ids(self):
        responses = [
            {'items': [{'id': {'videoId': 'abcdefghijk'}}, {'id': {'videoId': 'lmnopqrstuv'}}]},
            {'items': [{'id': 'abcdefghijk', 'status': {'license': 'creativeCommon'},
                        'snippet': {'title': 'An interview', 'channelTitle': 'Creator'}},
                       {'id': 'lmnopqrstuv', 'status': {'license': 'youtube'}, 'snippet': {'title': 'Other'}}]},
        ]
        with patch.dict('os.environ', {'YOUTUBE_API_KEY': 'test'}), patch.object(w, 'json_http', side_effect=responses):
            candidates = c.discover(MagicMock(), api=w)
        self.assertEqual(len(candidates), 1)
        self.assertEqual(candidates[0]['content_type'], 'clipper')
        self.assertEqual(candidates[0]['source_video_id'], 'abcdefghijk')


class RotationTests(unittest.TestCase):
    def run_scheduler(self, root, process):
        with patch.object(w, 'ROOT', root), patch.object(w, 'STATE', root/'state'), \
                patch.object(w, 'OUTPUT', root/'output'), patch('sys.argv', ['worker.py']), \
                patch.dict('os.environ', {'MAX_JOBS_PER_RUN': '3', 'TARGET_SECONDS': '30'}), \
                patch.object(w, 'process', side_effect=process), contextlib.redirect_stdout(io.StringIO()):
            w.main()
        return w.load(root/'state'/'queue.json', {})

    def make_state(self, root, jobs):
        w.atomic_json(root/'state'/'queue.json', {'schema_version': 3, 'jobs': {
            key: {'id': key, 'title': key, 'status': 'QUEUED', 'category': category,
                  'created_at': key, 'youtube_signal': {'status': 'not_checked'}}
            for key, category in jobs}})

    def test_three_distinct_completed_stories_then_next_category(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.make_state(root, [(f'world-story-{i}', 'world_news') for i in range(3)] +
                                  [(f'science-story-{i}', 'science') for i in range(3)])
            seen = []
            def complete(job, *args):
                seen.append(job['category']); job['status'] = 'REVIEW_REQUIRED'
            state = self.run_scheduler(root, complete)
            self.assertEqual(seen, ['world_news']*3)
            self.assertEqual(state['content_batch']['completed'], 3)
            self.run_scheduler(root, complete)
            self.assertEqual(seen, ['world_news']*3 + ['science']*3)

    def test_holds_do_not_count_or_trigger_a_category_switch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.make_state(root, [('world-blocked','world_news'), ('world-one','world_news'),
                                   ('world-two','world_news'), ('science-next','science')])
            def complete(job, *args):
                if job['id'] == 'world-blocked': raise w.Hold('Source unavailable')
                job['status'] = 'REVIEW_REQUIRED'
            state = self.run_scheduler(root, complete)
            self.assertEqual(state['content_batch']['completed'], 2)
            seen = []
            state = self.run_scheduler(root, lambda job,*a: seen.append(job['id']))
            self.assertEqual(seen, [])
            self.assertEqual(state['content_batch']['category'], 'world_news')

    def test_duplicate_story_does_not_count_as_a_third_video(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.make_state(root, [('one','science'), ('two','science'), ('three','science')])
            state = w.load(root/'state'/'queue.json', {})
            state['jobs']['one']['story_id'] = state['jobs']['two']['story_id'] = 'same event'
            w.atomic_json(root/'state'/'queue.json', state)
            def complete(job,*args): job['status'] = 'REVIEW_REQUIRED'
            state = self.run_scheduler(root, complete)
            self.assertEqual(state['content_batch']['completed'], 2)
            self.assertEqual(state['jobs']['two']['status'], 'HOLD')


if __name__ == '__main__':
    unittest.main()
